# Flowse 💸

**Predictive Financial Intelligence App**

A mobile-first personal finance app with:
- 📊 Budget & goal tracking
- 🏦 Account overview
- 🔄 Subscription tracker
- ⚡ AI-powered predictions (flags problems before they happen)
- 🤖 Live AI financial coach (powered by Claude)

## Tech Stack
- React 18
- Anthropic Claude API (for AI coach)
- Deployed on Vercel

## Getting Started

```bash
npm install
npm start
```

## Deploy
Connect this repo to [Vercel](https://vercel.com) for instant deployment.
